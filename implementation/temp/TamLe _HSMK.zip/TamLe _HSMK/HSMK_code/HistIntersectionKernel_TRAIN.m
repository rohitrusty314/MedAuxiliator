function [K] = HistIntersectionKernel_TRAIN(X, Y)
% X, Y : each row <--> sample
% X, Y : must be the same column
% K : intersection kernel
K = zeros(size(X,1), size(Y,1));
for i = 1:size(X, 1)
    for j = i:size(Y, 1)
        K(i,j) = sum(min(X(i,:), Y(j,:)));
        K(j,i) = K(i,j);
    end
end

end

