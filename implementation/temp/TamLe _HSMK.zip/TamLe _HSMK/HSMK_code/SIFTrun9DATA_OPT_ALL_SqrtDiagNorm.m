%% Data for SVM Training
disp('Normalize data for SVM Training');

% dirSVM = 'SIFTTest/SVMData/SIFT/ALL_SP/';

% dirSVM = 'SIFTTest/SVMData/SIFT/SC_LK_ALL_SP/';
% dirSVM = 'SIFTTest/SVMData/SIFT/SC_HIK_ALL_SP/';

% dirSVM = 'SIFTTest/SVMData/SIFT/ALL_MultiRSP/';

% dirSVM = 'SIFTTest/SVMData/SIFT/SC_LK_ALL_MultiRSP/';
dirSVM = 'SIFTTest/SVMData/SIFT/SC_HIK_ALL_MultiRSP/';
%% My bias weight kernel
% dirSVM = 'SIFTTest/SVMData/SIFT/ALL_MyBiasMultiRSP/';
% dirSVM = 'SIFTTest/SVMData/SIFT/ALL_MATCHING_SPK/';
% dirSVM = 'SIFTTest/SVMData/SIFT/ALL_MATCHING_HSMK/';

% dirSVMNorm = 'SIFTTest/SVMData/SIFT/ALL_SP_SDNorm/';

% dirSVMNorm = 'SIFTTest/SVMData/SIFT/SC_LK_ALL_SP_SDNorm/';
% dirSVMNorm = 'SIFTTest/SVMData/SIFT/SC_HIK_ALL_SP_SDNorm/';

% dirSVMNorm = 'SIFTTest/SVMData/SIFT/ALL_MultiRSP_SDNorm/';

% dirSVMNorm = 'SIFTTest/SVMData/SIFT/SC_LK_ALL_MultiRSP_SDNorm/';
dirSVMNorm = 'SIFTTest/SVMData/SIFT/SC_HIK_ALL_MultiRSP_SDNorm/';
%% My bias weight kernel
% dirSVMNorm = 'SIFTTest/SVMData/SIFT/ALL_MyBiasMultiRSP_SDNorm/';
% dirSVMNorm = 'SIFTTest/SVMData/SIFT/ALL_MATCHING_SPK_SDNorm/';
% dirSVMNorm = 'SIFTTest/SVMData/SIFT/ALL_MATCHING_HSMK_SDNorm/';

mkdir(dirSVMNorm);

% for FAST (VOCABULARY)
datasetName = 'CALTECH';

inputDataALL = [dirSVM '1vsAll_DATASET.mat'];
outputDataALL = [dirSVMNorm '1vsAll_DATASET.mat'];

% gramMatrix
matrixData = load(inputDataALL);
nMatrix = size(matrixData.gramMatrix, 1);
gramMatrix = zeros(nMatrix, nMatrix);

% Squareroot Diagonal normalization
for i=1:nMatrix
    disp(['...' num2str(i)]);
    for j=i:nMatrix
        normFactor = sqrt(matrixData.gramMatrix(i,i)*matrixData.gramMatrix(j,j));
        gramMatrix(i, j) = matrixData.gramMatrix(i,j)/normFactor;
        gramMatrix(j, i) = gramMatrix(i, j);
    end
end

save(outputDataALL, 'gramMatrix');    
disp('Normalize data for SVM Training');