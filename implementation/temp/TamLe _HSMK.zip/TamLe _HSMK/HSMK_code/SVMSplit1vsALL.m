function SVMSplit1vsALL(a, nC, sC, iC, outTrain, outTest)
% a : matrix of all data
% nC = 3;   % number of class
% sC = 1;   % number of samples in each class for training
% iC = 3;   % current considered class

nSamples = size(a, 1);  % number of samples in dataset

% Test
t_S = sC*nC + 1;
t_E = nSamples;
testALL = [t_S:t_E];

% Current class
i_S = sC*(iC-1) + 1;
i_E = sC*iC;
II = [i_S:i_E];

if(iC ~= 1)
    % Previous classes
    pi_S = 1;
    pi_E = sC*(iC-1);
    pI = [pi_S:pi_E];
end

if(iC ~= nC)
    % Following classes
    ai_S = sC*iC + 1;
    ai_E = sC*nC;
    aI = [ai_S:ai_E]; 
end

if(iC == 1)
    trainALL = [II aI];
elseif(iC == nC)
    trainALL = [II pI];
else
    trainALL = [II pI aI];
end

% number of Train & Test
numTrainSamples = size(trainALL, 2);
numValSamples = size(testALL, 2);

% gramMatrix
trainGramMatrix = [(1:numTrainSamples)', a(trainALL, trainALL)];
testGramMatrix = [(1:numValSamples)', a(testALL, trainALL)];

% save into files
save(outTrain, 'trainGramMatrix');
save(outTest, 'testGramMatrix');

end