function [perW, bBetter] = SVMKernel_VAL(testMAT, XTrainMAT, tPre, dirSVM)
%% Evaluate testMAT

Xtest = [];
Ytest = [];
numClass = size(testMAT, 1);
for i=1:numClass
    % SAMPLES
    Xtest = [Xtest ; testMAT{i}];
    % CLASS
    tmp = i*ones(size(testMAT{i}, 1), 1);
    Ytest = [Ytest ; tmp];
end

% NN : number of classifiers (multiclass --> transform into binary
% classification
NN = numClass;
modelFile = cell(NN, 1);
modelMat = cell(NN, 1);
result = zeros(size(Ytest, 1),NN);

numTestSamples = size(Xtest, 1);
disp('TEST ...');
for idClass = 1:numClass
    modelFile{idClass} = [dirSVM num2str(idClass) 'vsAll.mat'];
    tmp = load(modelFile{idClass});
    modelMat{idClass} = tmp.model;     

    testGramMatrix = [(1:numTestSamples)', HistIntersectionKernel(Xtest, XTrainMAT{idClass})];
    
    %[predict_label, accuracy, prob_estimates] = svmpredict(heart_scale_label, heart_scale_inst, model, '-b 1');
    [predictLabel, accuracy, probEstimates] = svmpredict(Ytest, testGramMatrix, modelMat{idClass}, '-b 1');

    for k=1:size(probEstimates,1)
        result(k, idClass) = probEstimates(k,1);
    end

    disp(['...' num2str(idClass) 'vsAll : FINISH !!!']);
end

Ypre = zeros(size(Ytest,1), 1);
nR = 0;
nW = 0;

disp('CALCULATE....');
for i=1:size(Ytest,1)
    Ypre(i) = ArgmaxNUM(result(i,:));
    if(Ytest(i) == Ypre(i))
        nR = nR + 1;
    else
        nW = nW + 1;
    end
end

perW = nR/(nR+nW);
disp(['numR = ' num2str(nR) '      nW = ' num2str(nW) '        ==>  %R = ' num2str(perW)]);
bBetter = 0;
if(perW > tPre)
    save([dirSVM 'Result'], 'Ypre', 'nR', 'nW','perW');
    bBetter = 1;
end
end