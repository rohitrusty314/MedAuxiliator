% Data for SVM Training
disp('Data for SVM Training');

% dirSVM = 'SIFTTest/SVMData/SIFT/ALL_SP/';
% dirSVM = 'SIFTTest/SVMData/SIFT/ALL_MultiRSP/';
% dirSVM = 'SIFTTest/SVMData/SIFT/ALL_MyBiasMultiRSP/';
% dirSVM = 'SIFTTest/SVMData/SIFT/ALL_MATCHING_SPK/';
% dirSVM = 'SIFTTest/SVMData/SIFT/ALL_MATCHING_HSMK/';
%% Normalize
% dirSVM = 'SIFTTest/SVMData/SIFT/ALL_SP_SDNorm/';
% dirSVM = 'SIFTTest/SVMData/SIFT/ALL_MultiRSP_SDNorm/';
% dirSVM = 'SIFTTest/SVMData/SIFT/ALL_MyBiasMultiRSP_SDNorm/';
% dirSVM = 'SIFTTest/SVMData/SIFT/ALL_MATCHING_SPK_SDNorm/';
dirSVM = 'SIFTTest/SVMData/SIFT/ALL_MATCHING_HSMK_SDNorm/';

% for FAST (VOCABULARY)
datasetName = 'CALTECH';

% dirDATA = 'SIFTTest/SVMData/SIFT/SP/';
% dirDATA = 'SIFTTest/SVMData/SIFT/MultiRSP/';
% dirDATA = 'SIFTTest/SVMData/SIFT/MyBiasMultiRSP/';
% dirDATA = 'SIFTTest/SVMData/SIFT/MATCHING_SPK/';
% dirDATA = 'SIFTTest/SVMData/SIFT/MATCHING_HSMK/';
%% Normalize
% dirDATA = 'SIFTTest/SVMData/SIFT/SP_SDNorm/';
% dirDATA = 'SIFTTest/SVMData/SIFT/MultiRSP_SDNorm/';
% dirDATA = 'SIFTTest/SVMData/SIFT/MyBiasMultiRSP_SDNorm/';
% dirDATA = 'SIFTTest/SVMData/SIFT/MATCHING_SPK_SDNorm/';
dirDATA = 'SIFTTest/SVMData/SIFT/MATCHING_HSMK_SDNorm/';

mkdir(dirDATA);

inputDataALL = [dirSVM '1vsAll_DATASET.mat'];       
% gramMatrix
load(inputDataALL);

%% SET UP FOR CALTECH101
numClass = 102;
numTrainClass = 30;

biasNegTimes = numClass-1;
for idClass=1:numClass
% for idClass=1:20
    disp(['Class : ' num2str(idClass) ' vs ALL']);

    outputTrain = [dirDATA num2str(idClass) 'vsAll_Train_' num2str(biasNegTimes)];
    outputTest  = [dirDATA num2str(idClass) 'vsAll_Test_' num2str(biasNegTimes)];

    SVMSplit1vsALL(gramMatrix, numClass, numTrainClass, idClass, outputTrain, outputTest);
end
    
disp('Data for SVM Training');