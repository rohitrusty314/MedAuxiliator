function ImageSIFTed(inFName, outFName)
%% Dense SIFT - LableMeToolbox - MIT
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% SIFT parameters: - FROM LabelMeToolbox
SIFTparam.grid_spacing = 1; % distance between grid centers
SIFTparam.patch_size = 16; % size of patch from which to compute SIFT descriptor (it has to be a factor of 4)
% CONSTANTS (you can not change this)
% SIFTw = SIFTparam.patch_size/2; % boundary
% COMPUTE SIFT: the output is a matrix [nrows x ncols x 128]
% SIFT = LMdenseSift(img, '', SIFTparam);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Read Image 
imgS = imread(inFName);
img  = im2double(imgS);
% img = RGB2Lab(imgD); %--> convert to CIELab

siftImg = LMdenseSift(img, '', SIFTparam);

%% Save filter responses
save(outFName, 'siftImg');