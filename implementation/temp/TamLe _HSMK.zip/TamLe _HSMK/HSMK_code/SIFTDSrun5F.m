% Need : 3.8GB RAM for (SIFTrun4F setup) <all in matlab : 4.5GB RAM)
% Computer 6GB RAM is OK !!!
%% CONFIG
fileSIFTSet = 'SIFTTest2/FastSIFTVocabulary/SIFTSet.mat';
fileSIFTVocabulary = 'SIFTTest2/FastSIFTVocabulary/SIFTVocabulary.mat';

% fileSIFTSet = 'SIFTTest4/FastSIFTVocabulary/SIFTSet.mat';
% fileSIFTVocabulary = 'SIFTTest4/FastSIFTVocabulary/SIFTVocabulary.mat';
%% build texton vocabulary
disp('Build SIFT Vocabulary');

kCluster = 800;

% normFilterSet : subsampling filter set
load(fileSIFTSet);

% LITEKMEAN
[siftSet siftVocabulary] = litekmeans(pointSIFTSet', kCluster);
siftVocabulary = siftVocabulary';

% save texton vocabulary
save(fileSIFTVocabulary, 'siftVocabulary');
disp('Build SIFT Vocabulary : FINISH !!!');