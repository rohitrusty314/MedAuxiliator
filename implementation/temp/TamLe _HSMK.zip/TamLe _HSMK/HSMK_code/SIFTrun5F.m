%% build texton vocabulary
disp('Build SIFT Vocabulary');

kCluster = 800;

fileSIFTSet = 'SIFTTest/FastSIFTVocabulary/SIFTSet.mat';
fileSIFTVocabulary = 'SIFTTest/FastSIFTVocabulary/SIFTVocabulary.mat';

% normFilterSet : subsampling filter set
load(fileSIFTSet);

% LITEKMEAN
[siftSet siftVocabulary] = litekmeans(pointSIFTSet', kCluster);
siftVocabulary = siftVocabulary';

% save texton vocabulary
save(fileSIFTVocabulary, 'siftVocabulary');
disp('Build SIFT Vocabulary : FINISH !!!');