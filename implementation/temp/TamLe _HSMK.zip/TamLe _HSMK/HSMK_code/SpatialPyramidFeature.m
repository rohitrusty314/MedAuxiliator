%% fix bugs Nov 17th, 2010
% by Tam T. Le
%-----------------------------
function [spHistImg] = SpatialPyramidFeature(featureImg, numVW, LMAX)
% featureImg = zeros(11, 13);
% numVW = 400;
% LMAX = 2;

%% Build spatial pyramid histogram of feature
spHistImg = [];

xI = size(featureImg, 1);
yI = size(featureImg, 2);

nKernel = 9;
nSigma = 3;
wKernel = zeros(nKernel, 1);
for i=1:nKernel
    wKernel(i) = exp(-i*i/(2*nSigma*nSigma));
end
% normalize weight
wKernel = wKernel./sum(wKernel);
wSpatialPool = [wKernel(7) wKernel(4) wKernel(1)];

% Spatial Pyramid Histogram
for L = 0:LMAX
    numStep = 2^L;
    lxRegion = floor(xI/numStep);
    lyRegion = floor(yI/numStep);
    
    %% Spatial Pyramid
    wSpatial = 1;
    if(L==0)
        wSpatial = 2^(-LMAX);
    else
        wSpatial = 2^(-LMAX + L - 1);
    end
    %% My Level
%     wSpatial = 2^(-LMAX + L);
    
    %% My Scale & Level-Scale
%     wSpatial = 4^(-LMAX + L);
    
    %% My Bias 
%     wSpatial = 1;
    %% SPECTIAL
%     wSpatial = wSpatialPool(L+1);
           
%     MX = floor(xI/lxRegion)*lxRegion;
%     MY = floor(yI/lyRegion)*lyRegion;
    MX = numStep*lxRegion;
    MY = numStep*lyRegion;
    
    borderSizeX = lxRegion*(2^L) - 1;
    borderSizeY = lyRegion*(2^L) - 1;
    
    for xx = 1:lxRegion:MX
        for yy = 1:lyRegion:MY
            reg.minX = xx;
            reg.maxX = min(xx + lxRegion -1, xI);
            if(reg.maxX > borderSizeX)
                reg.maxX = xI;
            end
            
            reg.minY = yy;
            reg.maxY = min(yy + lyRegion -1, yI);
            if(reg.maxY > borderSizeY)
                reg.maxY = yI;
            end

            % histRegion(numVW, 1)
             histRegion = RegionHistogram(featureImg, numVW, reg);
            
             spHistImg = [spHistImg ; (wSpatial*histRegion)];
        end
    end
end
end