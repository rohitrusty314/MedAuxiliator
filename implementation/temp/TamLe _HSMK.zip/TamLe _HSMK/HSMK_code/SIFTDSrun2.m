%% CONFIG
% datasetName = 'CALTECH2';
% dirFilterImage = 'SIFTTest2/SIFTImage';

datasetName = 'CALTECH4';
dirFilterImage = 'SIFTTest4/SIFTImage';
%% filter image
disp('Dense SIFT Image');

orgDatasetName = 'CALTECH';
inFileType = '.jpg';
outFileType = '.mat';

load dataset.mat;
numClass = size(dataset.Train, 1);
% matlabpool open 8
for i=1:numClass
    % Number of files
    numTrain = size(dataset.Train{i}, 1);
    numTest = size(dataset.Test{i}, 1);
    
    % Make correspondence directory
    tmp = dataset.Train{i}{1};
    % CHANGE THE DOWNSCALEDATASET
    tmp = regexprep(tmp, orgDatasetName, datasetName);
    
    findSplit = strfind(tmp, '/');
    idSplit = findSplit(size(findSplit, 2))-1;
    tmpDir = tmp(1:idSplit);
    makeDir = regexprep(tmpDir, datasetName, dirFilterImage);
    mkdir(makeDir);
    
    % Train : make filter image
    parfor id=1:numTrain
        inFile = dataset.Train{i}{id}
        % Change DOWNSCALE DATASET
        inFile = regexprep(inFile, orgDatasetName, datasetName);
        
        tmpFile = regexprep(inFile, datasetName, dirFilterImage);
        outFile = regexprep(tmpFile, inFileType, outFileType);        
        ImageSIFTed(inFile, outFile);
    end
    
    % Test filter image
    parfor id=1:numTest
        inFile = dataset.Test{i}{id}
        % Change DOWNSCALE DATASET
        inFile = regexprep(inFile, orgDatasetName, datasetName);
        
        tmpFile = regexprep(inFile, datasetName, dirFilterImage);
        outFile = regexprep(tmpFile, inFileType, outFileType);
        ImageSIFTed(inFile, outFile);
    end
end

% matlabpool close
disp('Dense SIFT Image : FINISH !!!');