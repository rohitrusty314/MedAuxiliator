% Update Dec 30th, 2010
% Parallel HIK
% Tam T. Le
%------------------------------------------
function [K] = HistIntersectionKernel_ALL(X)
% X each row <--> sample
% K : intersection kernel
N = size(X,1);
K = zeros(N, N);

matlabpool open 8
for i = 1:N
    disp(['...' num2str(i)]);
    xiRow = X(i,:);
    parfor j = i:N
        K(i,j) = sum(min(xiRow, X(j,:)));
%         K(j,i) = K(i,j);
    end
end
matlabpool close

for i = 1:N
    disp(['...' num2str(i) '...FILLED']);
    for j = (i+1):N
        K(j,i) = K(i,j);
    end
end

end
