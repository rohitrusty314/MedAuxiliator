%% histogram of SIFT
disp('Spatial Pyramid Histogram of SIFT');

% for FAST (VOCABULARY)
datasetName = 'CALTECH';
dirSIFTImage = 'SIFTTest/FastSIFTVocImage';

%%------------------------------------------------------------
% NOTES : CONFIG FUNCTION : SpatialPyramidFeature
% dirSpaPyrHistSIFTImage = 'SIFTTest/FastSpaPyrHistSIFTImage';

dirSpaPyrHistSIFTImage = 'SIFTTest/MySPHistSIFTImage';
% dirSpaPyrHistSIFTImage = 'SIFTTest/MyScaleSPHistSIFTImage';
% dirSpaPyrHistSIFTImage = 'SIFTTest/MyLevelSPHistSIFTImage';
% dirSpaPyrHistSIFTImage = 'SIFTTest/MyBiasSPHistSIFTImage';

inFileType = '.jpg';
outFileType = '.mat';
numSIFT = 800;

% Level of Spatial Pyramid (LMAX = 0 --> Bag of words)
LMAX = 2;

load dataset.mat;
numClass = size(dataset.Train, 1);

for i=1:numClass
% for i=1:52
    % Number of files
    numTrain = size(dataset.Train{i}, 1);
    numTest = size(dataset.Test{i}, 1);  
    
    % Make correspondence directory
    tmp = dataset.Train{i}{1};
    findSplit = strfind(tmp, '/');
    idSplit = findSplit(size(findSplit, 2))-1;
    tmpDir = tmp(1:idSplit);
    makeDir = regexprep(tmpDir, datasetName, dirSpaPyrHistSIFTImage);
    mkdir(makeDir);
    
    % Train : Spatial Pyramid image
    for id=1:numTrain
        trainFile = dataset.Train{i}{id};
        % input filename
        tmpFile = regexprep(trainFile, datasetName, dirSIFTImage);
        inFile  = regexprep(tmpFile, inFileType, outFileType)
        
        % output filename
        tmpFile = regexprep(trainFile, datasetName, dirSpaPyrHistSIFTImage);
        outFile  = regexprep(tmpFile, inFileType, outFileType);
        
        % siftVocImg(x, y) : SIFT image
        load(inFile);
        
        % Calculate Spatial Pyramid Histogram of feature
        spHistImg = SpatialPyramidFeature(siftVocImg, numSIFT, LMAX);
        
        % Save SIFT Image
        save(outFile, 'spHistImg');
    end    
    
    % Test : Spatial Pyramid image
    for id=1:numTest
        testFile = dataset.Test{i}{id};
        % input filename
        tmpFile = regexprep(testFile, datasetName, dirSIFTImage);
        inFile  = regexprep(tmpFile, inFileType, outFileType)
        
        % output filename
        tmpFile = regexprep(testFile, datasetName, dirSpaPyrHistSIFTImage);
        outFile  = regexprep(tmpFile, inFileType, outFileType);
        
        % siftVocImg(x, y) : SIFT image
        load(inFile);
        
        % Calculate Spatial Pyramid Histogram of feature
        spHistImg = SpatialPyramidFeature(siftVocImg, numSIFT, LMAX);
        
        % Save SIFT Image
        save(outFile, 'spHistImg');
    end
end

disp('Spatial Pyramid Histogram of SIFT : FINISH !!!');