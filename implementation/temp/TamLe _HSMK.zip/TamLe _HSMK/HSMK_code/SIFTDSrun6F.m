%% CONFIG 
% datasetName = 'CALTECH2';
% dirSIFTImage =  'SIFTTest2/SIFTImage';
% dirSIFTVocImage = 'SIFTTest2/FastSIFTVocImage';
% fileSIFTVocabulary = 'SIFTTest2/FastSIFTVocabulary/SIFTVocabulary.mat';

datasetName = 'CALTECH4';
dirSIFTImage =  'SIFTTest4/SIFTImage';
dirSIFTVocImage = 'SIFTTest4/FastSIFTVocImage';
fileSIFTVocabulary = 'SIFTTest4/FastSIFTVocabulary/SIFTVocabulary.mat';

%% SIFTize the dataset (FAST)
disp('SIFTize the dataset');

orgDatasetName = 'CALTECH';
mkdir(dirSIFTVocImage);

inFileType = '.jpg';
outFileType = '.mat';

load dataset.mat;
numClass = size(dataset.Train, 1);

% Load SIFT texton vocabulary --> siftVocabulary(n, d) : n sift in d
% dimension
load(fileSIFTVocabulary);
siftVocTree = kdtree(siftVocabulary);

% matlabpool open 8
for i=1:numClass
    % Number of files
    numTrain = size(dataset.Train{i}, 1);
    numTest = size(dataset.Test{i}, 1);
    
    % Make correspondence directory
    tmp = dataset.Train{i}{1};
    % CHANGE DATASET
    tmp = regexprep(tmp, orgDatasetName, datasetName);
    
    findSplit = strfind(tmp, '/');
    idSplit = findSplit(size(findSplit, 2))-1;
    tmpDir = tmp(1:idSplit);
    makeDir = regexprep(tmpDir, datasetName, dirSIFTVocImage);
    mkdir(makeDir);
    
    % Train : SIFTize image
    for id=1:numTrain
        trainFile = dataset.Train{i}{id};
        % CHANGE DATASET
        trainFile = regexprep(trainFile, orgDatasetName, datasetName);
        
        % input filename
        tmpFile = regexprep(trainFile, datasetName, dirSIFTImage);
        inFile  = regexprep(tmpFile, inFileType, outFileType)
        
        % output filename
        tmpFile = regexprep(trainFile, datasetName, dirSIFTVocImage);
        outFile  = regexprep(tmpFile, inFileType, outFileType);
        
        % siftImg(x, y, d) # x,y : 2 dimensions of filter image - d :
        % number of filter bands
        load(inFile);
        siftVocImg = zeros(size(siftImg, 1),size(siftImg, 2));
        for xx=1:size(siftImg, 1)
            for yy=1:size(siftImg, 2)
                siftVocImg(xx,yy) = kdtree_closestpoint(siftVocTree, reshape(siftImg(xx,yy,:),1, size(siftImg,3)));
            end
        end
        
        % Save texton Image
        save(outFile, 'siftVocImg');
    end    
    
    % Test : SIFTize image
    for id=1:numTest
        testFile = dataset.Test{i}{id};
        % CHANGE DATASET
        testFile = regexprep(testFile, orgDatasetName, datasetName);
        
        % input filename
        tmpFile = regexprep(testFile, datasetName, dirSIFTImage);
        inFile  = regexprep(tmpFile, inFileType, outFileType)
        
        % output filename
        tmpFile = regexprep(testFile, datasetName, dirSIFTVocImage);
        outFile  = regexprep(tmpFile, inFileType, outFileType);
        
        % siftImg(x, y, d) # x,y : 2 dimensions of filter image - d :
        % number of filter bands
        load(inFile);
        siftVocImg = zeros(size(siftImg, 1),size(siftImg, 2));
        for xx=1:size(siftImg, 1)
            for yy=1:size(siftImg, 2)
                siftVocImg(xx,yy) = kdtree_closestpoint(siftVocTree, reshape(siftImg(xx,yy,:),1, size(siftImg,3)));
            end
        end
        
        % Save texton Image
        save(outFile, 'siftVocImg');
    end
end
% matlabpool close

disp('SIFTize the dataset : FINISH !!!');