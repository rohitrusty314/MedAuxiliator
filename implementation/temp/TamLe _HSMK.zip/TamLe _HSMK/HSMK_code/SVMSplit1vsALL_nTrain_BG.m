function SVMSplit1vsALL_nTrain_BG(a, nC, sC, iC, outTrain, outTest, nTrain)
% a : matrix of all data
% nC = 3;   % number of class
% sC = 1;   % number of samples in each class for training
% iC = 3;   % current considered class

% CONFIG
% idBG = 1;
sizeBG = 50;

nSamples = size(a, 1);  % number of samples in dataset

% Test
t_S = sC*nC + 1 + sizeBG;
t_E = nSamples;
testALL = [t_S:t_E];

% Current class
i_S = sC*(iC-1) + 1;
i_E = sC*iC - nTrain;
II = [i_S:i_E];

if(iC ~= 2)
    % Previous classes
    pI=[];
    for i=2:(iC-1)
        pi_S = sC*(i-1) + 1;
        pi_E = sC*i - nTrain;
        
        pI=[pI [pi_S:pi_E]];
    end
%     pi_S = 1;
%     pi_E = sC*(iC-1) - nTrain;
%     pI = [pi_S:pi_E];
end

if(iC ~= nC)
    % Following classes
    aI = [];
    for i=(iC+1):nC
        ai_S = sC*(i-1) + 1;
        ai_E = sC*i - nTrain;
        aI = [aI [ai_S:ai_E]]; 
    end
%     ai_S = sC*iC + 1;
%     ai_E = sC*nC - nTrain;
%     aI = [ai_S:ai_E]; 
end

if(iC == 2)
    trainALL = [II aI];
elseif(iC == nC)
    trainALL = [II pI];
else
    trainALL = [II pI aI];
end

% number of Train & Test
numTrainSamples = size(trainALL, 2);
numValSamples = size(testALL, 2);

% gramMatrix
trainGramMatrix = [(1:numTrainSamples)', a(trainALL, trainALL)];
testGramMatrix = [(1:numValSamples)', a(testALL, trainALL)];

% save into files
save(outTrain, 'trainGramMatrix');
save(outTest, 'testGramMatrix');

end