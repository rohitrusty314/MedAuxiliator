function [perW, bBetter] = SVMPreKernel_VAL_OptMem(testKernel, YTest, tPre, dirSVM)
%% Evaluate testMAT
% [tPre bBetter]= SVMPreKernel_VAL(testKernel, YTest, bestcv, dirSVM);
numClass = size(testKernel, 1);

% NN : number of classifiers (multiclass --> transform into binary
% classification
NN = numClass;
% modelFile = cell(NN, 1);
% modelMat = cell(NN, 1);
result = zeros(size(YTest, 1),NN);

disp('TEST ...');
for idClass = 1:numClass
%     modelFile{idClass} = [dirSVM num2str(idClass) 'vsAll.mat'];
    modelFile = [dirSVM num2str(idClass) 'vsAll.mat'];
%     tmp = load(modelFile{idClass});
    
    % model
    load(modelFile);
%     modelMat{idClass} = tmp.model;     
  
    %[predict_label, accuracy, prob_estimates] = svmpredict(heart_scale_label, heart_scale_inst, model, '-b 1');
    % testGramMatrix
    load(testKernel{idClass});

    %     [predictLabel, accuracy, probEstimates] = svmpredict(YTest, testGramMatrix, modelMat{idClass}, '-b 1');
    [predictLabel, accuracy, probEstimates] = svmpredict(YTest, testGramMatrix, model, '-b 1');

    for k=1:size(probEstimates,1)
        result(k, idClass) = probEstimates(k,1);
    end

    clear testGramMatrix;
    disp(['...' num2str(idClass) 'vsAll : FINISH !!!']);
end

Ypre = zeros(size(YTest,1), 1);
nR = 0;
nW = 0;

disp('CALCULATE....');
for i=1:size(YTest,1)
    Ypre(i) = ArgmaxNUM(result(i,:));
    if(YTest(i) == Ypre(i))
        nR = nR + 1;
    else
        nW = nW + 1;
    end
end

perW = nR/(nR+nW);
disp(['numR = ' num2str(nR) '      nW = ' num2str(nW) '        ==>  %R = ' num2str(perW)]);
bBetter = 0;
if(perW > tPre)
    save([dirSVM 'Result'], 'Ypre', 'nR', 'nW','perW');
    bBetter = 1;
end
end