%% Random choose training & testing files from database
% Settings (30 training & <=50 testing)
disp('Build training & testing set from dataset');
inFolder = 'CALTECH';
dataFile = 'dataset.mat';
fileType = '*.jpg';
numTrain = 30;
numTest = 50;

% Program
subFolder = dir(inFolder);
numSubFolder = size(subFolder,1);

% itself & parent folder
numClassFolder = numSubFolder - 2;
cellClassFolder = cell(numClassFolder, 1);
id = 1;
for i=1:numSubFolder
    if ((subFolder(i).isdir == 1) && ...
        (strcmp(subFolder(i).name,'.') == 0) && ...
        (strcmp(subFolder(i).name,'..')== 0) )
        
        cellClassFolder{id} = [inFolder '/' subFolder(i).name];
        id = id + 1;
    end
end

fileSet = cell(numClassFolder, 1);
dataset.Train = cell(numClassFolder, 1);
dataset.Test = cell(numClassFolder, 1);

for i=1:numClassFolder
    fileSet{i} = dir(fullfile(cellClassFolder{i}, fileType));
    numFiles = size(fileSet{i}, 1);
    randSet = randperm(numFiles);
    
    dataset.Train{i} = cell(numTrain, 1);
    
    rNumTest = numFiles - numTrain;
    if(rNumTest > numTest)
        rNumTest = numTest;
    end
    
    dataset.Test{i} = cell(rNumTest, 1);
    
    for id = 1:numTrain
        dataset.Train{i}{id} = [cellClassFolder{i} '/' fileSet{i}(randSet(id)).name];
    end
    
    for id = 1:rNumTest
        dataset.Test{i}{id} = [cellClassFolder{i} '/' fileSet{i}(randSet(id + numTrain)).name];
    end
end

save(dataFile, 'dataset');
disp('Build training & testing set from dataset : FINISHED !!!');