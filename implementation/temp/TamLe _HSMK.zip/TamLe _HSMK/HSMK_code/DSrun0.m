%% Downscale dataset (1/2)
%% CONFIG FOR EACH DOWNSCALE
% downscaleDatasetName = 'CALTECH2';
% scale = 0.5;

downscaleDatasetName = 'CALTECH4';
scale = 0.25;

%% PROGRAM
disp('Downscale dataset');

datasetName = 'CALTECH';
load dataset.mat;
numClass = size(dataset.Train, 1);

for i=1:numClass
    % Number of files
    numTrain = size(dataset.Train{i}, 1);
    numTest = size(dataset.Test{i}, 1);
    
    % Make correspondence directory
    tmp = dataset.Train{i}{1};
    findSplit = strfind(tmp, '/');
    idSplit = findSplit(size(findSplit, 2))-1;
    tmpDir = tmp(1:idSplit);
    makeDir = regexprep(tmpDir, datasetName, downscaleDatasetName);
    mkdir(makeDir);
    
    % Train : donwscale image
    for id=1:numTrain
        inFile = dataset.Train{i}{id}        
        outFile = regexprep(inFile, datasetName, downscaleDatasetName);
        
        imgSource = imread(inFile);
        imgDouble = im2double(imgSource);
        imgDS = imresize(imgDouble, scale);
        imwrite(imgDS, outFile, 'jpg');
    end
    
    % Test filter image
    for id=1:numTest
        inFile = dataset.Test{i}{id}        
        outFile = regexprep(inFile, datasetName, downscaleDatasetName);
        
        imgSource = imread(inFile);
        imgDouble = im2double(imgSource);
        imgDS = imresize(imgDouble, scale);
        imwrite(imgDS, outFile, 'jpg');
    end
end

disp('Downscale dataset : FINISH !!!');