%% dense SIFT image
disp('Dense SIFT Image');

datasetName = 'CALTECH';
dirFilterImage = 'SIFTTest/SIFTImage';
inFileType = '.jpg';
outFileType = '.mat';

load dataset.mat;
numClass = size(dataset.Train, 1);
matlabpool open 8
for i=1:numClass
    % Number of files
    numTrain = size(dataset.Train{i}, 1);
    numTest = size(dataset.Test{i}, 1);
    
    % Make correspondence directory
    tmp = dataset.Train{i}{1};
    findSplit = strfind(tmp, '/');
    idSplit = findSplit(size(findSplit, 2))-1;
    tmpDir = tmp(1:idSplit);
    makeDir = regexprep(tmpDir, datasetName, dirFilterImage);
    mkdir(makeDir);
    
    % Train : make sift image
    parfor id=1:numTrain
        inFile = dataset.Train{i}{id}
        tmpFile = regexprep(inFile, datasetName, dirFilterImage);
        outFile = regexprep(tmpFile, inFileType, outFileType);        
        ImageSIFTed(inFile, outFile);
    end
    
    % Test sift image
    parfor id=1:numTest
        inFile = dataset.Test{i}{id}
        tmpFile = regexprep(inFile, datasetName, dirFilterImage);
        outFile = regexprep(tmpFile, inFileType, outFileType);
        ImageSIFTed(inFile, outFile);
    end
end
matlabpool close

disp('Dense SIFT Image : FINISH !!!');