%% Build pyramid histogram of SIFT feature
disp('Build multiresolution spatial pyramid histogram of SIFT');

% for FAST (VOCABULARY)
datasetName = 'CALTECH';

%% Spatial Pyramid (SPARSE CODING)
dirOrgHistSIFTImage = 'SIFTTest/SC_MySPHistSIFTImage';
dir128HistSIFTImage = 'SIFTTest2/SC_MySPHistSIFTImage';
dir64HistSIFTImage  = 'SIFTTest4/SC_MySPHistSIFTImage';

dirPyramidHistSIFTImage = 'SIFTTest/SC_MultiRSPHistSIFTImage2';

%% Spatial Pyramid
% dirOrgHistSIFTImage = 'SIFTTest/MySPHistSIFTImage';
% dir128HistSIFTImage = 'SIFTTest2/MySPHistSIFTImage';
% dir64HistSIFTImage  = 'SIFTTest4/MySPHistSIFTImage';
% 
% dirPyramidHistSIFTImage = 'SIFTTest/MultiRSPHistSIFTImage2';
%% My Scale - Level
% dirOrgHistSIFTImage = 'SIFTTest/MySPHistSIFTImage';
% dir128HistSIFTImage = 'SIFTTest2/MySPHistSIFTImage';
% dir64HistSIFTImage  = 'SIFTTest4/MySPHistSIFTImage';
% 
% dirPyramidHistSIFTImage = 'SIFTTest/MyMultiRSPHistSIFTImage';

%% My Level
% dirOrgHistSIFTImage = 'SIFTTest/MyLevelSPHistSIFTImage';
% dir128HistSIFTImage = 'SIFTTest2/MyLevelSPHistSIFTImage';
% dir64HistSIFTImage  = 'SIFTTest4/MyLevelSPHistSIFTImage';
% 
% dirPyramidHistSIFTImage = 'SIFTTest/MyLevelMultiRSPHistSIFTImage';

%% My Scale
% dirOrgHistSIFTImage = 'SIFTTest/MyScaleSPHistSIFTImage';
% dir128HistSIFTImage = 'SIFTTest2/MyScaleSPHistSIFTImage';
% dir64HistSIFTImage  = 'SIFTTest4/MyScaleSPHistSIFTImage';
% 
% dirPyramidHistSIFTImage = 'SIFTTest/MyScaleMultiRSPHistSIFTImage';

%% My Bias
% dirOrgHistSIFTImage = 'SIFTTest/MyBiasSPHistSIFTImage';
% dir128HistSIFTImage = 'SIFTTest2/MyBiasSPHistSIFTImage';
% dir64HistSIFTImage  = 'SIFTTest4/MyBiasSPHistSIFTImage';
% 
% dirPyramidHistSIFTImage = 'SIFTTest/MyBiasMultiRSPHistSIFTImage';

inFileType = '.jpg';
outFileType = '.mat';

% Pyramid weight 1
% wOrg = 0.5;
% w128 = 0.25;
% w64  = 0.25;

% Pyramid weight 2
wOrg = 0.25;
w128 = 0.25;
w64  = 0.5;

% % My Level-Scale & Level (Multiresolution)
% wOrg = 0.25;
% w128 = 0.5;
% w64  = 1;

% My Scale
% wOrg = 4^(-2);
% w128 = 4^(-1);
% w64  = 1; %(4^0)

% My Bias
% wOrg = 1;
% w128 = 1;
% w64  = 1;

load datasetSC45.mat;
% load dataset.mat;
numClass = size(dataset.Train, 1);

for i=1:numClass
    % Number of files
    numTrain = size(dataset.Train{i}, 1);
    numTest  = size(dataset.Test{i}, 1);  
    
    % Make correspondence directory
    tmp = dataset.Train{i}{1};
    findSplit = strfind(tmp, '/');
    idSplit = findSplit(size(findSplit, 2))-1;
    tmpDir = tmp(1:idSplit);
    makeDir = regexprep(tmpDir, datasetName, dirPyramidHistSIFTImage);
    mkdir(makeDir);
    
    % Train : pyramid histogram of SIFT image
    for id=1:numTrain
        trainFile = dataset.Train{i}{id};
        
        % output filename
        tmpFile  = regexprep(trainFile, datasetName, dirPyramidHistSIFTImage);
        outFile  = regexprep(tmpFile, inFileType, outFileType)
        
        %--------Multiresolution SPATIAL PYRAMID HISTOGRAM-------------
        % input filename
        % DB-ORG FILE
        tmpFile = regexprep(trainFile, datasetName, dirOrgHistSIFTImage);
        inFile  = regexprep(tmpFile, inFileType, outFileType);
        % spHistImg(numVW*numHist, 1)
        load(inFile);
        multiRSPHistImg = wOrg * spHistImg;
        
        % DB-128 FILE
        tmpFile = regexprep(trainFile, datasetName, dir128HistSIFTImage);
        inFile  = regexprep(tmpFile, inFileType, outFileType);
        % spHistImg(numVW*numHist, 1)
        load(inFile);
        multiRSPHistImg = [multiRSPHistImg ; (w128 * spHistImg)];
        
        % DB-64 FILE
        tmpFile = regexprep(trainFile, datasetName, dir64HistSIFTImage);
        inFile  = regexprep(tmpFile, inFileType, outFileType);
        % spHistImg(numVW*numHist, 1)
        load(inFile);
        multiRSPHistImg = [multiRSPHistImg ; (w64 * spHistImg)];
        %-----------------------------------
        
        % Save SIFT Image
        save(outFile, 'multiRSPHistImg');
    end    
    
    % SIFTTest : pyramid histogram of SIFT image
    for id=1:numTest
        testFile = dataset.Test{i}{id};
        
        % output filename
        tmpFile  = regexprep(testFile, datasetName, dirPyramidHistSIFTImage);
        outFile  = regexprep(tmpFile, inFileType, outFileType)
        
        %--------Multiresolution SPATIAL PYRAMID HISTOGRAM-------------
        % input filename
        % DB-ORG FILE
        tmpFile = regexprep(testFile, datasetName, dirOrgHistSIFTImage);
        inFile  = regexprep(tmpFile, inFileType, outFileType);
        % spHistImg(numVW*numHist, 1)
        load(inFile);
        multiRSPHistImg = wOrg * spHistImg;
        
        % DB-128 FILE
        tmpFile = regexprep(testFile, datasetName, dir128HistSIFTImage);
        inFile  = regexprep(tmpFile, inFileType, outFileType);
        % spHistImg(numVW*numHist, 1)
        load(inFile);
        multiRSPHistImg = [multiRSPHistImg ; (w128 * spHistImg)];
        
        % DB-64 FILE
        tmpFile = regexprep(testFile, datasetName, dir64HistSIFTImage);
        inFile  = regexprep(tmpFile, inFileType, outFileType);
        % spHistImg(numVW*numHist, 1)
        load(inFile);
        multiRSPHistImg = [multiRSPHistImg ; (w64 * spHistImg)];
        %-----------------------------------
        
        % Save SIFT Image
        save(outFile, 'multiRSPHistImg');
    end   
end

disp('Bucleaild multiresolution spatial pyramid histogram of SIFT : FINISH !!!');