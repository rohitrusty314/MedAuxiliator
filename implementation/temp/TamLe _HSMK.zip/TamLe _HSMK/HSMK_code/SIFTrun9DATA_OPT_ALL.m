%% Data for SVM Training
disp('Data for SVM Training');

% dirSVM = 'SIFTTest/SVMData/SIFT/ALL_SP/';
% dirSVM = 'SIFTTest/SVMData/SIFT/SC_LK_ALL_SP/';
% dirSVM = 'SIFTTest/SVMData/SIFT/SC_HIK_ALL_SP/';

% dirSVM = 'SIFTTest/SVMData/SIFT/ALL_MultiRSP/';
% dirSVM = 'SIFTTest/SVMData/SIFT/SC_LK_ALL_MultiRSP/';
dirSVM = 'SIFTTest/SVMData/SIFT/SC_HIK_ALL_MultiRSP/';
%% My scale-level weight kernel
%  dirSVM = 'SIFTTest/SVMData/SIFT/ALL_MyMultiRSP/';
%% My scale weight kernel
% dirSVM = 'SIFTTest/SVMData/SIFT/ALL_MyScaleMultiRSP/';
%% My level weight kernel
% dirSVM = 'SIFTTest/SVMData/SIFT/ALL_MyLevelMultiRSP/';
%% My bias weight kernel
% dirSVM = 'SIFTTest/SVMData/SIFT/ALL_MyBiasMultiRSP/';

mkdir(dirSVM);

% for FAST (VOCABULARY)
datasetName = 'CALTECH';

% dirPyramidHistSIFTImage = 'SIFTTest/MySPHistSIFTImage';
% dirPyramidHistSIFTImage = 'SIFTTest/SC_MySPHistSIFTImage';

% dirPyramidHistSIFTImage = 'SIFTTest/MultiRSPHistSIFTImage2';
dirPyramidHistSIFTImage = 'SIFTTest/SC_MultiRSPHistSIFTImage2';

%% My Weight kernel (Scale-Level weight)
% dirPyramidHistSIFTImage = 'SIFTTest/MyMultiRSPHistSIFTImage';
%% My scale weight kernel
% dirPyramidHistSIFTImage = 'SIFTTest/MyScaleMultiRSPHistSIFTImage';
%% My level weight kernel
% dirPyramidHistSIFTImage = 'SIFTTest/MyLevelMultiRSPHistSIFTImage';
%% My bias weight kernel
% dirPyramidHistSIFTImage = 'SIFTTest/MyBiasMultiRSPHistSIFTImage';

perValidation = 1;
inFileType = '.jpg';
outFileType = '.mat';

% Pyramid multiresolution
% nDim = 1200;    %3 resolution - visual word : 400 --> nDim = 400*3;

% Spatial Pyramid
% nDim = 16800; % LMAX = 2 --> 21 * 800(VW) = 16800
% Multiresolution Sptial Pyramid
nDim = 50400; % Res = 3, Lmax = 2 --> 21 * 800(VW) * 3 = 50400

% Spatial Pyramid
% nDim = 8400; % LMAX = 2 --> 21 * 400(VW) = 8400
% Multiresolution Sptial Pyramid
% nDim = 25200; % Res = 3, Lmax = 2 --> 21 * 400(VW) * 3 = 25200

load datasetSC45.mat;
% load dataset.mat;
numClass = size(dataset.Train, 1);

% Build format for data training
trainMAT = cell(numClass, 1);
valMAT = cell(numClass, 1);

for i=1:numClass
    % FORMAT SVM Light : one row <--> one sample
    % Number of files (TRAINING)
    numTrain = size(dataset.Train{i}, 1);
    
    trainingSample = zeros(numTrain, nDim);
    % Train : SIFTize image
%     i
    for id=1:numTrain
        trainFile = dataset.Train{i}{id};
        
        % input filename
        tmpFile = regexprep(trainFile, datasetName, dirPyramidHistSIFTImage);
        inFile  = regexprep(tmpFile, inFileType, outFileType);
        
        % pyramidHistImg(nDim, 1) : pyramid hist feature
        load(inFile);
        % ### Pyramid Resolution
        % trainingSample(id, :) = pyramidHistImg';
        % ### Spatial Pyramid 
        % trainingSample(id, :) = spHistImg';
        % ### multiRSPHistImg
%         id
        trainingSample(id, :) = multiRSPHistImg';
    end    
    
    trainMAT{i} = trainingSample;
    
    % Number of files (VALIDATION)
    numTest = size(dataset.Test{i}, 1);
    numVal = floor(perValidation*numTest);
    
    valSample = zeros(numVal, nDim);
    % Train : SIFTize image
    for id=1:numVal
        valFile = dataset.Test{i}{id};
        
        % input filename
        tmpFile = regexprep(valFile, datasetName, dirPyramidHistSIFTImage);
        inFile  = regexprep(tmpFile, inFileType, outFileType);
        
        % pyramidHistImg(nDim, 1) : pyramid hist feature
        load(inFile);
        
        % ### Pyramid Resolution
        % valSample(id, :) = pyramidHistImg';
        % ### Spatial Pyramid
        % valSample(id, :) = spHistImg';
        % ### Multiresolution spatial pyramid
        valSample(id, :) = multiRSPHistImg';
    end    
    
    valMAT{i} = valSample;
end
% Release
clear trainingSample;
clear valSample;
clear multiRSPHistImg;
clear spHistImg;
clear dataset;

dataALL = [];
% TRAINING SAMPLES
for i=1:numClass
    dataALL = [dataALL ; trainMAT{i}];
end
clear trainMAT;
% TESTING SAMPLES
for i=1:numClass
    dataALL = [dataALL ; valMAT{i}];
end
clear valMAT;

outputDataALL = [dirSVM '1vsAll_DATASET.mat'];       

% gramMatrix = LinearKernel_ALL(dataALL);       
gramMatrix = HistIntersectionKernel_ALL(dataALL);        

save(outputDataALL, 'gramMatrix');
    
disp('Data for SVM Training');