%% SVM Training with fixed parameter
disp('SVMLib Training (1 vs all) : Optimized parameter in PreHIK SVM');

%% SIFT
% dirSVM = 'SIFTTest/SVMLib/SP_OptimizedParameter_PreHIK2/';
% dirSVM = 'SIFTTest/SVMLib/MultiRSP_OptimizedParameter_PreHIK2/';
% dirSVM = 'SIFTTest/SVMLib/MyMultiRSP_OptimizedParameter_PreHIK/';
% dirSVM = 'SIFTTest/SVMLib/MyLevelMultiRSP_OptimizedParameter_PreHIK/';
% dirSVM = 'SIFTTest/SVMLib/MyScaleMultiRSP_OptimizedParameter_PreHIK/';
% dirSVM = 'SIFTTest/SVMLib/MyBiasMultiRSP_OptimizedParameter_PreHIK/';

% % dirSVM = 'SIFTTest/SVMDLib/SIFT/MATCHING_SPK/';
% dirSVM = 'SIFTTest/SVMDLib/SIFT/MATCHING_HSMK/';

% dirSVM = 'SIFTTest/SVMLib/SIFT/SP/';
% dirSVM = 'SIFTTest/SVMLib/SIFT/SC_LK_SP/';
% dirSVM = 'SIFTTest/SVMLib/SIFT/SC_HIK_SP/';

% dirSVM = 'SIFTTest/SVMLib/SIFT/MultiRSP/';
% dirSVM = 'SIFTTest/SVMLib/SIFT/SC_LK_MultiRSP/';
% dirSVM = 'SIFTTest/SVMLib/SIFT/SC_HIK_MultiRSP/';
%% Normalize
% dirSVM = 'SIFTTest/SVMLib/SIFT/SP_SDNorm/';
% dirSVM = 'SIFTTest/SVMLib/SIFT/SC_LK_SP_SDNorm/';
% dirSVM = 'SIFTTest/SVMLib/SIFT/SC_HIK_SP_SDNorm/';

% dirSVM = 'SIFTTest/SVMLib/SIFT/MultiRSP_SDNorm/';
dirSVM = 'SIFTTest/SVMLib/SIFT/SC_LK_MultiRSP_SDNorm/';
% dirSVM = 'SIFTTest/SVMLib/SIFT/SC_HIK_MultiRSP_SDNorm/';

% dirSVM = 'SIFTTest/SVMLib/SIFT/MyBiasMultiRSP_SDNorm/';
% dirSVM = 'SIFTTest/SVMLib/SIFT/MATCHING_SPK_SDNorm/';
% dirSVM = 'SIFTTest/SVMLib/SIFT/MATCHING_HSMK_SDNorm/';

% for FAST (VOCABULARY)
%% SIFT
% dirPyramidHistTextonImage = 'SIFTTest/SVMData/SIFT/SP/';
% dirPyramidHistTextonImage = 'SIFTTest/SVMData/SIFT/SC_LK_SP/';
% dirPyramidHistTextonImage = 'SIFTTest/SVMData/SIFT/SC_HIK_SP/';

% dirPyramidHistTextonImage = 'SIFTTest/SVMData/SIFT/MultiRSP/';
% dirPyramidHistTextonImage = 'SIFTTest/SVMData/SIFT/SC_LK_MultiRSP/';
% dirPyramidHistTextonImage = 'SIFTTest/SVMData/SIFT/SC_HIK_MultiRSP/';

% dirPyramidHistTextonImage = 'SIFTTest/SVMData/SIFT/MyMultiRSP/';
% dirPyramidHistTextonImage = 'SIFTTest/SVMData/SIFT/MyLevelMultiRSP/';
% dirPyramidHistTextonImage = 'SIFTTest/SVMData/SIFT/MyScaleMultiRSP/';
% dirPyramidHistTextonImage = 'SIFTTest/SVMData/SIFT/MyBiasMultiRSP/';

% dirPyramidHistTextonImage = 'SIFTTest/SVMData/SIFT/MATCHING_SPK/';
% dirPyramidHistTextonImage = 'SIFTTest/SVMData/SIFT/MATCHING_HSMK/';

% dirPyramidHistTextonImage = 'SIFTTest/SVMData/SIFT/SP_SDNorm/';
% dirPyramidHistTextonImage = 'SIFTTest/SVMData/SIFT/SC_LK_SP_SDNorm/';
% dirPyramidHistTextonImage = 'SIFTTest/SVMData/SIFT/SC_HIK_SP_SDNorm/';

% dirPyramidHistTextonImage = 'SIFTTest/SVMData/SIFT/MultiRSP_SDNorm/';
dirPyramidHistTextonImage = 'SIFTTest/SVMData/SIFT/SC_LK_MultiRSP_SDNorm/';
% dirPyramidHistTextonImage = 'SIFTTest/SVMData/SIFT/SC_HIK_MultiRSP_SDNorm/';

% dirPyramidHistTextonImage = 'SIFTTest/SVMData/SIFT/MyBiasMultiRSP_SDNorm/';

% dirPyramidHistTextonImage = 'SIFTTest/SVMData/SIFT/MATCHING_SPK_SDNorm/';
% dirPyramidHistTextonImage = 'SIFTTest/SVMData/SIFT/MATCHING_HSMK_SDNorm/';

mkdir(dirSVM);
biasNegTimes = 101;

% CONFIG FOR 15-SCENE DATASET
% numClass = 15;
% numClassSamples = 100;

% CONFIG FOR 17-FLOWER DATASET
% numClass = 17;
% numClassSamples = 40;

% CONFIG FOR 102-CALTECH101
numClass = 102;
% numClassSamples = 30;
numClassSamples = 30;

% CONFIG FOR 257-CALTECH256
% numClass = 257;
% numClassSamples = 30;

% Create y for testing phase
% dataset.Test;

% load dataset.mat;
load datasetSC.mat;
YTest = [];
for i=1:numClass
    % CLASS
    tmp = i*ones(size(dataset.Test{i},1), 1);
    YTest = [YTest ; tmp];
end
clear dataset;

%% Program
%%%%%%%%%%%%%%%%
tPre = 0;
bestcv = 0;
gBias = 0;

for biasNegTimes = 101:101
for log2c = 1:1%-4:10%-1:3,
%%%%%%%%%%%%%%%
    testKernel = cell(numClass, 1);
    for idClass=1:numClass
        disp(['Class : ' num2str(idClass) ' vs ALL']);
        disp('Make training data');

        output = [dirSVM num2str(idClass) 'vsAll'];
        %$$$ #Pos / # Neg
        numPosSamples = numClassSamples;
        numNegSamples = numClassSamples * biasNegTimes;
            
        YTrain_Pos =  ones(numPosSamples, 1);
        YTrain_Neg = -ones(numNegSamples, 1);
        YTrain = [YTrain_Pos ; YTrain_Neg];
               
        gramMatrixTrain = [dirPyramidHistTextonImage num2str(idClass) 'vsAll_Train_' num2str(biasNegTimes) '.mat'];
        gramMatrixTest  = [dirPyramidHistTextonImage num2str(idClass) 'vsAll_Test_' num2str(biasNegTimes) '.mat'];
        
        % 'trainGramMatrix'
        load(gramMatrixTrain);
        % 'testGramMatrix' 
%         load(gramMatrixTest);
%         testKernel{idClass} = testGramMatrix;
        testKernel{idClass} = gramMatrixTest;
        
        cmd = ['-t 4 -b 1 -c ', num2str(2^log2c), ' -w-1 1 -w1 ', num2str(biasNegTimes)];
        model = svmtrain(YTrain, trainGramMatrix, cmd);
        save(output, 'model');
        
        clear trainGramMatrix;
    end
    
    [tPre bBetter]= SVMPreKernel_VAL_OptMem(testKernel, YTest, bestcv, dirSVM);
%%%%%%%%%%%%%%%%%%%%%
    %PREDICT ON VAL
    if (bBetter == 1),
        bestcv = tPre; bestc = 2^log2c; gBias = biasNegTimes;
    end
    fprintf('%g %g(best c=%g, bias=%g, rate=%g)\n', log2c, bBetter, bestc, gBias, bestcv);
end
%%%%%%%%%%%%%%%%%%%%
end

disp('SVMLib Training (1 vs all) : Optimized parameter in PreHIK SVM');