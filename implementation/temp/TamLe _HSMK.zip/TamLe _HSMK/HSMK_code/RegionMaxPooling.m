function [histRegion] = RegionMaxPooling(img, reg)
%% img : image of visual words loaded from mat files
% numVW : number of visual words used
% reg : region for histogram. It's a struct included 4 parts
% + minX, minY, maxX, maxY

regImg = img(reg.minX:reg.maxX, reg.minY:reg.maxY, :);
regPooling = reshape(regImg, size(regImg,1)*size(regImg,2), size(regImg,3));
histRegion = max(abs(regPooling))';

end

