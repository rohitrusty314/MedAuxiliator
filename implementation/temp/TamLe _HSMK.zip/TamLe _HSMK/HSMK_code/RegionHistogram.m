function [histRegion] = RegionHistogram(img, numVW, reg)
%% img : image of visual words loaded from mat files
% numVW : number of visual words used
% reg : region for histogram. It's a struct included 4 parts
% + minX, minY, maxX, maxY

histRegion = zeros(numVW, 1);
regImg = img(reg.minX:reg.maxX, reg.minY:reg.maxY);
for i=1:numVW
    histRegion(i) = size(regImg(regImg==i), 1);
end

end

