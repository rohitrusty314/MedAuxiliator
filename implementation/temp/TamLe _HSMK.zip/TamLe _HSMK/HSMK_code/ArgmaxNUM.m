function [idmax] = ArgmaxNUM(dataVector)
idmax = 1;
for i=2:size(dataVector, 2)
    if(dataVector(i) > dataVector(idmax))
        idmax = i;
    end
end
end
