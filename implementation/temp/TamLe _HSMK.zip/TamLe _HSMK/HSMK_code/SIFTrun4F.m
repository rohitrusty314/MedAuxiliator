%% subsampling SIFT dataset
disp('Subsampling SIFT dataset');

% Image size : 300x300
% Approximate number for initialize SIFT Set
minX = 16;
minY = 16;
minSample = 30;
numClass = 102;
numDim = 128;
bSize = minX*minY*minSample*numClass;
SIFTSet = zeros(2*bSize, numDim);
idFS = 0;

datasetName = 'CALTECH';
dirSIFTImage = 'SIFTTest/SIFTImage';
dirSIFTVocabulary = 'SIFTTest/FastSIFTVocabulary';
fileSIFTSet = 'SIFTTest/FastSIFTVocabulary/SIFTSet.mat';
xSubSampling = 20;
ySubSampling = 20;
setSubSampling = 1;

mkdir(dirSIFTVocabulary);

inFileType = '.jpg';
outFileType = '.mat';

load dataset.mat;
numClass = size(dataset.Train, 1);

for i=1:numClass
    % Number of files
    numTrain = size(dataset.Train{i}, 1);
    
    % Train : make SIFT image
    for id=1:numTrain
        trainFile = dataset.Train{i}{id};
        tmpFile = regexprep(trainFile, datasetName, dirSIFTImage);
        inFile  = regexprep(tmpFile, inFileType, outFileType)
        % siftImg(x,y,z) / x,y : 2 dimension of an image & z : number
        % of SIFT
        load(inFile);
        
        xImg = size(siftImg, 1);
        randXImg = randperm(xImg);
        yImg = size(siftImg, 2);
        randYImg = randperm(yImg);
        
        xSubImg = floor(1.0*xImg/xSubSampling);
        ySubImg = floor(1.0*yImg/ySubSampling);
        
        for xx=1:xSubImg
            for yy=1:ySubImg
                idFS = idFS + 1;
                SIFTSet(idFS,:) = siftImg(randXImg(xx), randYImg(yy), :);
            end
        end
    end    
end

if(idFS < bSize)
    SIFTSet = SIFTSet(1:idFS, :);
else
    SIFTSet = SIFTSet(1:bSize, :);
end

if(setSubSampling == 1)
    pointSIFTSet = SIFTSet;
else
    randSIFTSet = randperm(idFS);
    numSIFTSet = floor(idFS/setSubSampling);

    pointSIFTSet = zeros(numSIFTSet, numDim);
    idNFS = 0;

    for i=1:numSIFTSet
        idNFS = idNFS + 1;
        pointSIFTSet(idNFS,:) = SIFTSet(randSIFTSet(i),:);
    end
end
idFS
save(fileSIFTSet, 'pointSIFTSet');
disp('Subsampling SIFT dataset : FINISH !!!');