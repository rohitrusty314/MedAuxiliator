%% SIFTize the dataset (FAST)
disp('SIFTize the dataset');

datasetName = 'CALTECH';
dirSIFTImage =  'SIFTTest/SIFTImage';
dirSIFTVocImage = 'SIFTTest/FastSIFTVocImage';
fileSIFTVocabulary = 'SIFTTest/FastSIFTVocabulary/SIFTVocabulary.mat';

mkdir(dirSIFTVocImage);

inFileType = '.jpg';
outFileType = '.mat';

load dataset.mat;
numClass = size(dataset.Train, 1);

% Load SIFT texton vocabulary --> siftVocabulary(n, d) : n sift in d
% dimension
load(fileSIFTVocabulary);
siftVocTree = kdtree(siftVocabulary);

for i=1:numClass
    % Number of files
    numTrain = size(dataset.Train{i}, 1);
    numTest = size(dataset.Test{i}, 1);
    
    % Make correspondence directory
    tmp = dataset.Train{i}{1};
    findSplit = strfind(tmp, '/');
    idSplit = findSplit(size(findSplit, 2))-1;
    tmpDir = tmp(1:idSplit);
    makeDir = regexprep(tmpDir, datasetName, dirSIFTVocImage);
    mkdir(makeDir);
    
    % Train : SIFTize image
    for id=1:numTrain
        trainFile = dataset.Train{i}{id};
        % input filename
        tmpFile = regexprep(trainFile, datasetName, dirSIFTImage);
        inFile  = regexprep(tmpFile, inFileType, outFileType)
        
        % output filename
        tmpFile = regexprep(trainFile, datasetName, dirSIFTVocImage);
        outFile  = regexprep(tmpFile, inFileType, outFileType);
        
        % siftImg(x, y, d) # x,y : 2 dimensions of filter image - d :
        % number of filter bands
        load(inFile);
        siftVocImg = zeros(size(siftImg, 1),size(siftImg, 2));
        for xx=1:size(siftImg, 1)
            for yy=1:size(siftImg, 2)
                siftVocImg(xx,yy) = kdtree_closestpoint(siftVocTree, reshape(siftImg(xx,yy,:),1, size(siftImg,3)));
            end
        end
        
        % Save texton Image
        save(outFile, 'siftVocImg');
    end    
    
    % Test : SIFTize image
    for id=1:numTest
        testFile = dataset.Test{i}{id};
        % input filename
        tmpFile = regexprep(testFile, datasetName, dirSIFTImage);
        inFile  = regexprep(tmpFile, inFileType, outFileType)
        
        % output filename
        tmpFile = regexprep(testFile, datasetName, dirSIFTVocImage);
        outFile  = regexprep(tmpFile, inFileType, outFileType);
        
        % siftImg(x, y, d) # x,y : 2 dimensions of filter image - d :
        % number of filter bands
        load(inFile);
        siftVocImg = zeros(size(siftImg, 1),size(siftImg, 2));
        for xx=1:size(siftImg, 1)
            for yy=1:size(siftImg, 2)
                siftVocImg(xx,yy) = kdtree_closestpoint(siftVocTree, reshape(siftImg(xx,yy,:),1, size(siftImg,3)));
            end
        end
        
        % Save texton Image
        save(outFile, 'siftVocImg');
    end
end

disp('SIFTize the dataset : FINISH !!!');